
import React from 'react';
import { Product } from '../types';
import PlusIcon from './icons/PlusIcon';
import MinusIcon from './icons/MinusIcon';

interface ProductCardProps {
    product: Product;
    quantity: number;
    onQuantityChange: (change: number) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, quantity, onQuantityChange }) => {
    return (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col transition-transform duration-300 hover:scale-105">
            <img src={product.imageUrl} alt={product.name} className="w-full h-48 object-cover" />
            <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-xl font-semibold text-emerald-800">{product.name}</h3>
                <p className="text-stone-600 mt-1 flex-grow">{product.description}</p>
                <div className="flex justify-between items-center mt-4">
                    <p className="text-2xl font-bold text-emerald-600">{product.price.toFixed(2)} lei</p>
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={() => onQuantityChange(-1)} 
                            disabled={quantity === 0}
                            className="p-2 rounded-full bg-amber-200 text-amber-800 disabled:bg-stone-200 disabled:text-stone-400 disabled:cursor-not-allowed hover:bg-amber-300 transition-colors"
                            aria-label={`Decrease quantity of ${product.name}`}
                        >
                            <MinusIcon />
                        </button>
                        <span className="text-xl font-bold w-8 text-center">{quantity}</span>
                        <button 
                            onClick={() => onQuantityChange(1)} 
                            className="p-2 rounded-full bg-amber-200 text-amber-800 hover:bg-amber-300 transition-colors"
                            aria-label={`Increase quantity of ${product.name}`}
                        >
                           <PlusIcon />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductCard;
