
import React, { useRef, useEffect } from 'react';
import { UserDetails } from '../types';

interface OrderFormProps {
    userDetails: UserDetails;
    isDeliveryAvailable: boolean;
    totalQuantity: number;
    deliveryMethod: 'delivery' | 'pickup';
    pickupLocation: 'The Office Business Center' | 'Sigma Shopping Center';
    onUserDetailsChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
    onDeliveryMethodChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onPickupLocationChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const OrderForm: React.FC<OrderFormProps> = ({ 
    userDetails, 
    isDeliveryAvailable, 
    totalQuantity,
    deliveryMethod,
    pickupLocation,
    onUserDetailsChange, 
    onSubmit,
    onDeliveryMethodChange,
    onPickupLocationChange
}) => {
    const showAddressField = isDeliveryAvailable && deliveryMethod === 'delivery';
    const addressRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (showAddressField && addressRef.current) {
            addressRef.current.focus();
        }
    }, [showAddressField]);

    return (
        <div className="bg-white rounded-lg shadow-lg p-6 sticky top-8">
            <h2 className="text-2xl font-semibold mb-4 text-emerald-700">Your Details</h2>
            <form onSubmit={onSubmit} className="space-y-4">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-stone-600">Full Name</label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name"
                        value={userDetails.name}
                        onChange={onUserDetailsChange}
                        required 
                        className="mt-1 block w-full px-3 py-2 bg-white border border-stone-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                    />
                </div>
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-stone-600">Phone Number</label>
                    <input 
                        type="tel" 
                        id="phone" 
                        name="phone"
                        value={userDetails.phone}
                        onChange={onUserDetailsChange}
                        required 
                        className="mt-1 block w-full px-3 py-2 bg-white border border-stone-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-stone-600">Delivery Option</label>
                    <div className="mt-2 space-y-2">
                        <div className="flex items-center">
                            <input
                                id="pickup"
                                name="deliveryMethod"
                                type="radio"
                                value="pickup"
                                checked={deliveryMethod === 'pickup'}
                                onChange={onDeliveryMethodChange}
                                className="focus:ring-emerald-500 h-4 w-4 text-emerald-600 border-stone-300"
                            />
                            <label htmlFor="pickup" className="ml-3 block text-sm font-medium text-stone-700">
                                Pickup
                            </label>
                        </div>
                        <div className="flex items-center">
                            <input
                                id="delivery"
                                name="deliveryMethod"
                                type="radio"
                                value="delivery"
                                checked={deliveryMethod === 'delivery'}
                                onChange={onDeliveryMethodChange}
                                disabled={!isDeliveryAvailable}
                                className="focus:ring-emerald-500 h-4 w-4 text-emerald-600 border-stone-300 disabled:text-stone-400"
                            />
                            <label htmlFor="delivery" className={`ml-3 block text-sm font-medium ${isDeliveryAvailable ? 'text-stone-700' : 'text-stone-400 cursor-not-allowed'}`}>
                                Local Delivery
                            </label>
                        </div>
                    </div>
                </div>
                
                <div className="transition-all duration-500 ease-in-out">
                    {!isDeliveryAvailable && totalQuantity > 0 && (
                         <div className="text-sm bg-amber-100 border-l-4 border-amber-500 text-amber-700 p-3 rounded-md">
                            <p className="font-bold">Delivery Unlocks Soon!</p>
                            <p>Add {3 - totalQuantity} more item(s) to qualify for local delivery.</p>
                        </div>
                    )}
                    {deliveryMethod === 'pickup' && (
                        <div className="mt-4 space-y-2 p-3 rounded-md bg-emerald-50 border-l-4 border-emerald-500">
                            <p className="block text-sm font-bold text-emerald-800">Choose Pickup Location</p>
                            <div className="flex items-center">
                                <input
                                    id="office-center"
                                    name="pickupLocation"
                                    type="radio"
                                    value="The Office Business Center"
                                    checked={pickupLocation === 'The Office Business Center'}
                                    onChange={onPickupLocationChange}
                                    className="focus:ring-emerald-500 h-4 w-4 text-emerald-600 border-stone-300"
                                />
                                <label htmlFor="office-center" className="ml-3 block text-sm font-medium text-stone-700">
                                    The Office Business Center
                                </label>
                            </div>
                            <div className="flex items-center">
                                <input
                                    id="sigma-center"
                                    name="pickupLocation"
                                    type="radio"
                                    value="Sigma Shopping Center"
                                    checked={pickupLocation === 'Sigma Shopping Center'}
                                    onChange={onPickupLocationChange}
                                    className="focus:ring-emerald-500 h-4 w-4 text-emerald-600 border-stone-300"
                                />
                                <label htmlFor="sigma-center" className="ml-3 block text-sm font-medium text-stone-700">
                                    Sigma Shopping Center
                                </label>
                            </div>
                        </div>
                    )}
                    <div className={`mt-4 transform transition-all duration-500 ${showAddressField ? 'opacity-100 max-h-40' : 'opacity-0 max-h-0 overflow-hidden'}`}>
                        <label htmlFor="address" className="block text-sm font-medium text-stone-600">Delivery Address (Local)</label>
                        <textarea 
                            ref={addressRef}
                            id="address" 
                            name="address"
                            value={userDetails.address}
                            onChange={onUserDetailsChange}
                            required={showAddressField}
                            rows={3}
                            className="mt-1 block w-full px-3 py-2 bg-white border border-stone-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                        />
                    </div>
                </div>

                <button 
                    type="submit"
                    disabled={totalQuantity === 0}
                    className="w-full bg-emerald-600 text-white font-bold py-3 px-4 rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors duration-300 disabled:bg-stone-400 disabled:cursor-not-allowed"
                >
                    Place Pre-Order
                </button>
            </form>
        </div>
    );
};

export default OrderForm;