
import React from 'react';
import { CartItem } from '../types';
import ShoppingCartIcon from './icons/ShoppingCartIcon';

interface OrderSummaryProps {
    items: CartItem[];
    totalPrice: number;
}

const OrderSummary: React.FC<OrderSummaryProps> = ({ items, totalPrice }) => {
    if (items.length === 0) {
        return null; // Don't show the summary if the cart is empty
    }

    return (
        <div className="fixed bottom-4 right-4 w-80 bg-white rounded-xl shadow-2xl p-5 border-t-4 border-emerald-600 transition-transform transform-gpu animate-slide-in-up">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-emerald-800">Your Order</h3>
                <ShoppingCartIcon />
            </div>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                {items.map(item => (
                    <div key={item.id} className="flex justify-between items-center text-sm">
                        <div className="text-stone-700">
                            <span className="font-medium">{item.name}</span>
                            <span className="text-stone-500"> x {item.quantity}</span>
                        </div>
                        <span className="font-semibold text-stone-800">{(item.price * item.quantity).toFixed(2)} lei</span>
                    </div>
                ))}
            </div>
            <div className="border-t border-stone-200 mt-4 pt-4 flex justify-between items-center">
                <span className="text-lg font-bold text-stone-800">Total</span>
                <span className="text-xl font-bold text-emerald-700">{totalPrice.toFixed(2)} lei</span>
            </div>
             <style>{`
                @keyframes slide-in-up {
                    from { transform: translateY(100%); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                .animate-slide-in-up {
                    animation: slide-in-up 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default OrderSummary;
